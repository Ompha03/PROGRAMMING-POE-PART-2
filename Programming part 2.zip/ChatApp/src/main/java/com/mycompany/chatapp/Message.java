/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Ompha
 */
public class Message {
    
    private String messageID;
    private String message;
    private String messageHash;
    private String recipient;
    private int messageNumber;
    
    private static int totalMessageSent = 0;
    private static int totalMessageStored = 0;
    private static int totalMessageDiscarded = 0;
    private static String sentMessages = "";
    private static String storedMessages = "";
    
    
    private static Path STORE_FILE = Paths.get("messages.json");
    
    public Message(int messageNumber, String recipient, String message) {
    this.message = message;
    this.messageNumber = messageNumber;
    this.recipient = recipient;

    this.messageID = generateMessageID();
    this.messageHash = CheckMessageHash();
}
    
    public Message(String messageID, int messageNumber, String recipient, String message) {
    this.message = message;
    this.messageNumber = messageNumber;
    this.recipient = recipient;

    this.messageID = messageID;
    this.messageHash = CheckMessageHash();
}
    
    static void setStoreFile(Path path) {
    STORE_FILE = path;
           }
     static void resetCounters() {
        totalMessageSent = 0;
        totalMessageStored = 0;
        totalMessageDiscarded = 0;
        sentMessages = "";
        storedMessages = "";
    }
    
     public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }
    
    public String generateMessageID(){
        
        Random random = new Random();
        String id = "";
        
        for (int i = 0 ; i<10 ; i++)
        {
            int digit = random.nextInt(10);
            id+=digit;
        }
        
        return id;
    }
    
    public boolean CheckMessageID(){
        
        return messageID.length() <= 10;
    }
    
    public String checkRecipientcell(){
        
        String cellRegex = ("\\+27\\d{9}$");
        
        if (recipient.matches(cellRegex)){
            return "Cell phone number successfully captured.";
        }
        else {
            return "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
        }
    }
    
    public boolean isRecipientValid(){
        
        return recipient.matches("\\+27\\d{9}$");
    }
    
    public String CheckMesssageLenth(){
        
        if(message.length() <= 250)
        {
            return "Message ready to send.";
        }else {
            
            int extraCharacters = message.length() - 250;
            return "Message exceeds 250 characters by " + extraCharacters + "; please reduce the size.";
        }
    }
    
    public boolean isMessageValid(){
        
        return message.length()<=250;
    }
    
    public String CheckMessageHash(){
        
        String[] words = message.trim().split("\\s+");
        
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        firstWord = firstWord.replaceAll("[^a-zA-Z0-9]", "");
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");
        
        String hash = messageID.substring(0, 2)
                +":"
                + messageNumber
                + ":"
                +firstWord
                +lastWord;
        
        return hash.toUpperCase();
    }
    
    public String sentMessage(int option){
        
        if (option ==1){
            
            totalMessageSent++;
            
            sentMessages += printMessageDetails()
                    +System.lineSeparator()
                    + "====================="
                    + System.lineSeparator();
            
            return "Message successfully sent.";
        }
        else if ( option == 2){
            totalMessageDiscarded++;
            return "Press 0 to delete the message.";
        }
        else if ( option == 3 ){
            totalMessageStored++;
            return "Message successfully stored.";
        }
        else {
            return "invalid option";
        }
    }
    
    public String storeMessage() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        try {
            List<Message> messages = new ArrayList<>();

            if (Files.exists(STORE_FILE)) {
                String json = Files.readString(STORE_FILE);
                Type listType = new TypeToken<List<Message>>() {}.getType();
                List<Message> loaded = gson.fromJson(json, listType);
                if (loaded != null) {
                    messages = loaded;
                }
            }
            
            messages.add(this);
            Files.writeString(STORE_FILE, gson.toJson(messages));

            return "Message successfully stored";
        } catch (IOException e) {
            return "Failed to store message: " + e.getMessage();
        }
    }
    
    public String printMessages(){
        
        if( sentMessages.isEmpty()){
            return "No messages sent";
        }
        return sentMessages;
    }
    
    public int returnTotalMessages(){
        
        return totalMessageSent;
    }
    
    public String printMessageDetails(){
         
        return "Message ID : " + messageID
                + System.lineSeparator()
                + "Messahe hash : " + messageHash
                + System.lineSeparator()
                + "Recipient : " +recipient
                +System.lineSeparator()
                + "Message : " + message;
    }
    
    public static String printSummary() {
    String line = System.lineSeparator();

    return "Total messages sent : " + totalMessageSent + line
            + "Total messages stored : " + totalMessageStored + line
            + "Total messages discarded : " + totalMessageDiscarded 
            ;
}
    
    
}
