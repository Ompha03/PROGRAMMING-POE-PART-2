/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;

import java.util.Scanner;

/**
 *  
 * 
 * @author Ompha maluma St105398986
 */
public class ChatApp {

    public static void main(String[] args) {
        
         Scanner input = new Scanner(System.in);
         
       //Declaration
        String firstName = "";
        String lastName = "";
        String userName = "";
        String password = "";
        String cellphoneNumber = "";
        
        boolean ValidUserName;
        boolean ValidPassword  ;
        boolean ValidCellphoneNumber ;
        
        System.out.println("=============================");
        System.out.println("     CHATAPP REGISTRATION     ");
        System.out.println("=============================");
        
        System.out.print("Enter your firstname: ");
        firstName = input.nextLine();
        
        System.out.print("Enter your lasttname: ");
        lastName = input.nextLine();
        
        /*prompting the user to enter the needed information and verifying if its in
         * correct format*/
        do
        {
            System.out.print("Enter Username: ");
            userName = input.nextLine();
            
            LogIn user = new LogIn(userName , "", "" );
            ValidUserName = user.checkUserName();
            
        }while(!ValidUserName);
        
        do
        {
             System.out.print("Enter password: ");
            password = input.nextLine();
            
            LogIn user = new LogIn(  "", password, "");
            ValidPassword = user.checkPasswordComplexity();
            
        }while(!ValidPassword);
        
        do
        {
            System.out.print("Enter cellphoneNumber: ");
            cellphoneNumber = input.nextLine();
            
            LogIn user = new LogIn(  userName , password , cellphoneNumber );
            ValidCellphoneNumber = user.checkCellPhoneNumber();
            
        }while(!ValidCellphoneNumber);
        
         System.out.println("");
        
        LogIn user = new LogIn(  userName , password , cellphoneNumber );
        
        System.out.println(user.getUserNameMessage());
        System.out.println(user.getPasswordMessage());
        System.out.println(user.getCellphoneNumebrMessage());
        
        System.out.println("");  
        System.out.println(" Registeration Successful ");
        
        //Login section
        
        System.out.println("=============================");
        System.out.println("     CHATAPP LOGIN     ");
        System.out.println("=============================");
        
       
           /* promptin the user to inter the login details  and comparing 
        *with thw information given during Registration
        */
            boolean loggedIn;
        do {
            System.out.print("Enter username to login: ");
            String logInUserName = input.nextLine();

            System.out.print("Enter password to login: ");
            String logInPassword = input.nextLine();

            loggedIn = user.loginUser(logInUserName, logInPassword);
            // displaying the output message
            System.out.println(user.returnLoginStatus(firstName, lastName, loggedIn));
        } while (!loggedIn);
        
   //Part 2 of the project starts here    
          
        System.out.println("======================");
        System.out.println(" WELCOME TO QUICKCHAT ");
        System.out.println("=======================");
      int answer;

do {
    System.out.println();
    System.out.println("======MENU=======");
    System.out.println("1. Send Messages");
    System.out.println("2. Show recent sent Messages");
    System.out.println("3. Quit");

    System.out.println("Select an option");
    answer = input.nextInt();
    input.nextLine();
        
        if (answer==1){
        
        System.out.println("How many messages would you wish to send");
        int numberOfMessages = input.nextInt();
        input.nextLine();
        
        for(int i = 0; i<numberOfMessages ; i++){
            
            System.out.println();
            System.out.println("Message " + (i+1));
            
            System.out.println("===================");
            
            String recipient;
            Message messageObject;
            
            do{
                System.out.println("Enter recipient cell number using +27");
                
                recipient = input.nextLine();
                
                messageObject = new Message(i, recipient , "Temporary messge");
                
                System.out.println(messageObject.checkRecipientcell());
                
            }while(!messageObject.isRecipientValid());
            
            String MessageText;
            
            do{
                System.out.println();
                System.out.println("Enter your message");
                MessageText = input.nextLine();
                
                messageObject = new Message(i, recipient , MessageText);
                
                System.out.println(messageObject.CheckMesssageLenth()); 
                
            }while(!messageObject.isMessageValid());
            
            Message finalMessage = new Message(i, recipient , MessageText);
            
            System.out.println();
            System.out.println("Generated Information");
            System.out.println("==========================");
            
            System.out.println("Message ID : "+ finalMessage.getMessageID());
            System.out.println("Message Hash: "+ finalMessage.getMessageHash());
            
            System.out.println();
            System.out.println("What would you like to do now?");
            System.out.println("1) Send Mesaage");
            System.out.println("2) Discard Message");
            System.out.println("3) Store Message");
            
            System.out.println("Select an option");
            
            int Option = input.nextInt();
            input.nextLine();
            
            if(Option == 1)
            {
                System.out.println(finalMessage.sentMessage(1));
                
                System.out.println();
                System.out.println("MESSAGE DETAILS");
                System.out.println(finalMessage.printMessageDetails());
            }
            else if(Option == 2)
            {
                System.out.println(finalMessage.sentMessage(2));
                
            }
            else if(Option == 3)
            {
                System.out.println(finalMessage.sentMessage(3));
                
                
            }else
            {
                System.out.println("Invalid ");
            }
        }
        
        System.out.println();
        System.out.println("====================");
        System.out.println("==SUMMARY==");
        System.out.println("====================");
        
        System.out.println(Message.printSummary());
        
        }
        
        else if (answer==2){
            System.out.println("Coming soon");
            
        }
        else if( answer == 3)
        {
            System.out.println("GOODBYE!!"
                    + "");
            input.close();
        }        
       }while(answer != 3);
input.close();
    }
    
   
}

