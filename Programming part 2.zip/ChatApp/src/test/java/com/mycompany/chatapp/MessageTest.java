/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @TempDir
    Path tempDir;

    private Message testMessage1;
    private Message testMessage2;

    @BeforeEach
    public void setUp() {
        Message.resetCounters();
        Message.setStoreFile(tempDir.resolve("messages.json"));

        // Test Data 1 from Rubric
        testMessage1 = new Message("0012345678", 0, "+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        // Test Data 2 from Rubric
        testMessage2 = new Message("0087654321", 1, "08575975889",
                "Hi Keegan, did you receive the payment?");
    }

    // 1. Test Message ID Creation & Length
    @Test
    public void testCheckMessageID() {
        Message m = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertNotNull(m.getMessageID());
        assertEquals(10, m.getMessageID().length());
        assertTrue(m.CheckMessageID());
    }

    // 2. Recipient Number - Success
    @Test
    public void testCheckRecipientCellSuccess() {
        assertEquals("Cell phone number successfully captured.", testMessage1.checkRecipientcell());
    }

    // 3. Recipient Number - Failure (missing +27)
    @Test
    public void testCheckRecipientCellFailure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.",
                testMessage2.checkRecipientcell());
    }

    // 4. Message Length - Success
    @Test
    public void testCheckMessageLengthSuccess() {
        assertEquals("Message ready to send.", testMessage1.CheckMesssageLenth());
    }

    // 5. Message Length - Failure (> 250 characters)
    @Test
    public void testCheckMessageLengthFailure() {
        Message longMessage = new Message("0012345678", 0, "+27718693002", "A".repeat(260));
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                longMessage.CheckMesssageLenth());
    }

    // 6. Message Hash
    @Test
    public void testCreateMessageHash() {
        assertEquals("00:0:HITONIGHT", testMessage1.getMessageHash());
    }

    // 7. Option 1 - Send Message
    @Test
    public void testSentMessageSend() {
        assertEquals("Message successfully sent.", testMessage1.sentMessage(1));
    }

    // 8. Option 2 - Disregard Message
    @Test
    public void testSentMessageDisregard() {
        assertEquals("Press 0 to delete the message.", testMessage1.sentMessage(2));
    }

    // 9. Option 3 - Store Message
    @Test
    public void testSentMessageStore() {
        assertEquals("Message successfully stored.", testMessage1.sentMessage(3));
    }
}